module.exports = {
  BOT_TOKEN: "7749971589:AAFEoLOx7j-57KRMfBqK-yhOvl4mpDaV2-Y", 
};