<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=DAA520&center=true&width=910&height=100&lines=THANKS FOR CHOOSING +NJABULO;WHATSAPP+BOT+CREATED+BY+NJABULO" alt="Typing SVG" /></a>




[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&size=30&pause=1000&color=0000FF&center=true&vCenter=true&width=815&height=60&lines=▇+▇+▇+▇+▇+▇+▇)](https://git.io/typing-svg) 




[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&size=30&pause=1000&color=0000FF&center=true&vCenter=true&width=815&height=60&lines=Njabulo+Jb+)](https://git.io/typing-svg) 

<p align="centre"><img src="https://files.catbox.moe/o9r08m.jpg" width="500" height="500" />




<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=DAA520&center=true&width=910&height=100&lines=+; 𝐁𝐎𝐓+ 𝐈𝐒+100%+𝐒𝐀𝐅𝐄+𝐎𝐍+𝐇𝐄𝐑𝐎𝐊𝐔" alt="Typing SVG" /></a>


<p align="center">
<a href="https://github.com/NjabuloJ/followers"><img title="Followers" src="https://img.shields.io/github/followers/NjabuloJ?color=blue&style=flat-square"></a>
<a href="https://github.com/NjabuloJ/Njabulo-Jb/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/NjabuloJ/Njabulo-Jb?color=blue&style=flat-square"></a>
<a href="https://github.com/NjabuloJ/Njabulo-Jb/network/members"><img title="Forks" src="https://img.shields.io/github/forks/NjabuloJ/Njabulo-Jb?color=blue&style=flat-square"></a>
<a href="https://github.com/NjabuloJ/Njabulo-Jb/"><img title="Size" src="https://img.shields.io/github/repo-size/NjabuloJ/Njabulo-Jb?style=flat-square&color=blue"></a>
<a href="https://github.com/NjabuloJ/Njabulo-Jb/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>
<p align='center'>
</p>

 <p align="center"><img src="https://profile-counter.glitch.me/{ENZO-MD}/count.svg" alt="Enzo :: Visitor's Count" old_src="https://profile-counter.glitch.me/{enzo}/count.svg" /></p>






## HOW TO GET BOT

  
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=𝗙𝗢𝗥𝗞+𝗔𝗡𝗗+𝗦𝗧𝗔𝗥+𝗥𝗘𝗣𝗢)](https://git.io/typing-svg)
 

  
   
   <a href="https://github.com/NjabuloJ/Njabulo-Jb/fork"><img title="FORK-REPO" src="https://img.shields.io/badge/FORK-REPO-h?color=blue&style=for-the-badge&logo=Nike" width="297" height="40.45"/></a></p>


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

 
 
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=𝗦𝗘𝗦𝗦𝗜𝗢𝗡+𝗜𝗗+𝗦𝗜𝗧𝗘+𝗜𝗦+𝗛𝗘𝗥𝗘)](https://git.io/typing-svg)
 


  <a href="https://fffi-0841e02d44bd.herokuapp.com/"><img title="GET-SESSION ID HERE" src="https://img.shields.io/badge/GET-SESSION ID HERE-h?color=green&style=for-the-badge&logo=nike" width="230" height="38.45"/></a></p>

  
  <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=blue&lines=𝐃𝐄𝐏𝐋𝐎𝐘+𝐎𝐍+𝐇𝐄𝐑𝐎𝐊𝐔)](https://git.io/typing-svg)


 
  

 
## 𝐅𝐎𝐑 𝐎𝐍𝐄-𝐓𝐀𝐏 𝐃𝐄𝐏𝐋𝐎𝐘𝐌𝐄𝐍𝐓 𝐔𝐒𝐄 𝐓𝐇𝐈𝐒 𝐁𝐔𝐓𝐓𝐎𝐍

   🕳IF YOU DON'T HAVE A HEROKU ACCOUNT...CREATE ONE
   
   <a href="https://signup.heroku.com/"><img title="CREATE-ACCOUNT" src="https://img.shields.io/badge/CREATE-ACCOUNT-h?color=blue&style=for-the-badge&logo=blue" width="180" height="43.45"/></a></p>

   ☢️IF YOU ALREADY HAVE A HEROKU ACCOUNT...DEPLOY NOW

 <a href="https://dashboard.heroku.com/new?template=https://github.com/NjabuloJ/Njabulo-JB1"><img title="DEPLOY-ON HEROKU" src="https://img.shields.io/badge/DEPLOY-ON HEROKU-h?color=blue&style=for-the-badge&logo=nike" width="220" height="38.45"/></a></p>

 
 [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&size=30&pause=1000&color=0000FF&center=true&vCenter=true&width=815&height=60&lines=▭+▬+▭+▬+▭+▬+▭+▬+▭+▬+▭)](https://git.io/typing-svg) 

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## FINAL REMARKS ON MY REPO (STATS)

![ Stats](https://github-readme-stats.vercel.app/api/pin/?username=Enzotech&repo=ENZO-MD&show_owner=true&theme=dark)









<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## CONTACT 
  DM FOR SERIOUS BUSINESS

   <a href="https://github.com/NjabuloJ/NjabuloJ-INFO"><img title="CONTACT-Njabulo" src="https://img.shields.io/badge/CONTACT-Njabulo-h?color=black&style=for-the-badge&logo=audi" width="240" height="45.45"/></a></p>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


DEPLOYMENT :

- [**NJABULO TECH**](https://github.com/NjabuloJ/Njabulo-jb)
- [**MARISEL TECH**](https://github.com/betingrich3/Mercedes)
- [**CHANNEL**](https://shorturl.at/q8ZuS)
- [**Developers YT**](https://youtube.com/watch?v=yuFuKu9SUIM)


</div>






<p align="center">
    <a href="https://chat.whatsapp.com/GfmBCCZR34g5EqMHpFLzZN">
        <img height="30" title="Support Group" src="https://img.shields.io/badge/Support%20Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white">
    </a>
</p>

## Njabulo support 

<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=DAA520&center=true&width=910&height=100&lines=MULT JB BOT +MAKE; STAR ⭐+AND+FORKS+BY+NJABULO" alt="Typing SVG" /></a>
